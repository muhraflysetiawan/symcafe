# Files That Can Be Safely Deleted

These files are from the old system and are not used by the new POS system.

## Root Directory Files (Old System)

### PHP Files - Old System Pages
- `barang.php` - Old product management (replaced by products.php)
- `kategori.php` - Old category management (replaced by categories.php)
- `customer.php` - Old customer management (not used in new system)
- `pembelian.php` - Old purchase management (not in new system)
- `penjualan.php` - Old sales page (replaced by pos.php)
- `pengaturan.php` - Old settings page (not in new system)
- `stok.php` - Old stock management (integrated into products.php)
- `struk.php` - Old receipt page (replaced by receipt.php)
- `users.php` - Old user management (replaced by cashiers.php)
- `laporan_pembelian.php` - Old purchase report (not in new system)
- `laporan_penjualan.php` - Old sales report (replaced by transactions.php)

### Duplicate/Unused Files
- `sidebar.php` - Old sidebar (replaced by includes/sidebar.php)
- `vendor.php` - Old vendor management (not in new system)

## Models Directory (Entire Folder - Old System)

All files in `models/` folder are from the old system and not used:
- `models/Barang.php`
- `models/Customer.php`
- `models/KategoriBarang.php`
- `models/Pembelian.php`
- `models/Pengaturan.php`
- `models/Penjualan.php`
- `models/User.php`
- `models/Vendor.php`

## Assets Directory

- `assets/css/dynamic.php` - Old dynamic CSS generator (not used, we use static style.css)

## Database Directory

- `database/pos_minimart.sql` - Empty file, not needed

---

## Summary

**Total files/folders to delete:**
- 12 PHP files in root directory
- 8 PHP files in models/ directory (entire folder)
- 1 CSS file in assets/css/
- 1 SQL file in database/

**Total: 22 files**

---

## Files to KEEP (Active System)

### Core System Files
- `index.php` - Redirect handler
- `login.php` - Login page
- `register.php` - Registration page
- `logout.php` - Logout handler
- `cafe_setup.php` - Café setup
- `dashboard.php` - Dashboard
- `unauthorized.php` - Access denied page
- `install.php` - Database installer

### Product Management (Owner Only)
- `products.php` - Product list
- `product_form.php` - Add/edit product

### Category Management (Owner Only)
- `categories.php` - Category list
- `category_form.php` - Add/edit category

### POS & Transactions
- `pos.php` - POS interface
- `process_transaction.php` - Process payment
- `receipt.php` - Receipt display
- `transactions.php` - Transaction history

### Cashier Management (Owner Only)
- `cashiers.php` - Cashier list
- `cashier_form.php` - Add/edit cashier

### User Management
- `profile.php` - User profile

### Includes (Layout Components)
- `includes/header.php`
- `includes/footer.php`
- `includes/sidebar.php`
- `includes/topnav.php`

### Configuration
- `config/config.php`
- `config/database.php`

### Database
- `database/schema.sql` - Active database schema

### Assets
- `assets/css/style.css` - Main stylesheet

### Documentation
- `README.md`
- `QUICKSTART.md`

