<?php
if (!isset($page_title)) {
    $page_title = APP_NAME;
}

// Load theme settings
$theme_colors = [
    'primary' => '#FFFFFF',
    'secondary' => '#252525',
    'accent' => '#3A3A3A'
];

if (isLoggedIn() && function_exists('getCafeId')) {
    try {
        $cafe_id = getCafeId();
        if ($cafe_id) {
            $db = new Database();
            $conn = $db->getConnection();
            $stmt = $conn->prepare("SELECT primary_color, secondary_color, accent_color FROM cafe_settings WHERE cafe_id = ?");
            $stmt->execute([$cafe_id]);
            $settings = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($settings) {
                $theme_colors['primary'] = $settings['primary_color'];
                $theme_colors['secondary'] = $settings['secondary_color'];
                $theme_colors['accent'] = $settings['accent_color'];
            }
        }
    } catch (Exception $e) {
        // Use default colors if there's an error
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title . ' - ' . APP_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css">
    <style>
        :root {
            --primary-black: <?php echo $theme_colors['secondary']; ?>;
            --primary-white: <?php echo $theme_colors['primary']; ?>;
            --accent-gray: <?php echo $theme_colors['accent']; ?>;
        }
    </style>
</head>
<body>
    <div class="main-container">
        <?php include 'includes/sidebar.php'; ?>
        <div class="main-content">
            <?php include 'includes/topnav.php'; ?>
            <div class="content">

