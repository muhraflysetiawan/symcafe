<?php
require_once 'config/config.php';
requireLogin();
requireCafeSetup();

$db = new Database();
$conn = $db->getConnection();
$cafe_id = getCafeId();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cart_data = json_decode($_POST['cart_data'] ?? '[]', true);
    $subtotal = (float)($_POST['subtotal_value'] ?? 0);
    $discount = (float)($_POST['discount_value'] ?? 0);
    $tax = (float)($_POST['tax_value'] ?? 0);
    $total = (float)($_POST['total_value'] ?? 0);
    $order_type = sanitizeInput($_POST['order_type'] ?? 'dine-in');
    $payment_method = sanitizeInput($_POST['payment_method'] ?? 'cash');
    $customer_name = sanitizeInput($_POST['customer_name'] ?? '');
    
    if (empty($cart_data) || $total <= 0) {
        $_SESSION['error'] = 'Invalid transaction data';
        header('Location: pos.php');
        exit();
    }
    
    try {
        $conn->beginTransaction();
        
        // Handle customer name
        $customer_id = null;
        if (!empty($customer_name)) {
            // Check if customer already exists
            $stmt = $conn->prepare("SELECT customer_id FROM customers WHERE cafe_id = ? AND name = ? LIMIT 1");
            $stmt->execute([$cafe_id, $customer_name]);
            $existing_customer = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($existing_customer) {
                $customer_id = $existing_customer['customer_id'];
            } else {
                // Create new customer
                $stmt = $conn->prepare("INSERT INTO customers (cafe_id, name) VALUES (?, ?)");
                $stmt->execute([$cafe_id, $customer_name]);
                $customer_id = $conn->lastInsertId();
            }
        }
        
        // Create order
        $stmt = $conn->prepare("INSERT INTO orders (cafe_id, cashier_id, customer_id, order_type, subtotal, discount, tax, total_amount, payment_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'paid')");
        $stmt->execute([$cafe_id, $_SESSION['user_id'], $customer_id, $order_type, $subtotal, $discount, $tax, $total]);
        $order_id = $conn->lastInsertId();
        
        // Add order items and update stock
        foreach ($cart_data as $item) {
            $item_id = (int)$item['id'];
            $quantity = (int)$item['quantity'];
            $price = (float)$item['price'];
            $subtotal_item = $price * $quantity;
            
            // Insert order item
            $stmt = $conn->prepare("INSERT INTO order_items (order_id, item_id, quantity, price, subtotal) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$order_id, $item_id, $quantity, $price, $subtotal_item]);
            
            // Update stock
            $stmt = $conn->prepare("UPDATE menu_items SET stock = stock - ? WHERE item_id = ? AND cafe_id = ?");
            $stmt->execute([$quantity, $item_id, $cafe_id]);
            
            // Auto-update status if stock reaches 0
            $stmt = $conn->prepare("UPDATE menu_items SET status = 'unavailable' WHERE item_id = ? AND cafe_id = ? AND stock <= 0");
            $stmt->execute([$item_id, $cafe_id]);
        }
        
        // Create payment record
        $stmt = $conn->prepare("INSERT INTO payments (order_id, payment_method, amount) VALUES (?, ?, ?)");
        $stmt->execute([$order_id, $payment_method, $total]);
        
        $conn->commit();
        
        header('Location: receipt.php?order_id=' . $order_id);
        exit();
        
    } catch (Exception $e) {
        $conn->rollBack();
        $_SESSION['error'] = 'Transaction failed: ' . $e->getMessage();
        header('Location: pos.php');
        exit();
    }
} else {
    header('Location: pos.php');
    exit();
}
?>

