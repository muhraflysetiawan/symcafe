<?php
$current_page = basename($_SERVER['PHP_SELF']);

// Get café logo
$db = new Database();
$conn = $db->getConnection();
$cafe_id = getCafeId();
$cafe_logo = null;

if ($cafe_id) {
    try {
        // Check if logo column exists
        $check_column = $conn->query("SHOW COLUMNS FROM cafes LIKE 'logo'");
        if ($check_column->rowCount() > 0) {
            $stmt = $conn->prepare("SELECT logo FROM cafes WHERE cafe_id = ?");
            $stmt->execute([$cafe_id]);
            $cafe = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($cafe && !empty($cafe['logo']) && file_exists($cafe['logo'])) {
                $cafe_logo = $cafe['logo'];
            }
        }
    } catch (PDOException $e) {
        // Column doesn't exist yet, use default
        $cafe_logo = null;
    }
}
?>
<aside class="sidebar">
    <div class="sidebar-header">
        <?php if ($cafe_logo): ?>
            <img src="<?php echo htmlspecialchars($cafe_logo); ?>" alt="Café Logo" style="max-width: 100%; max-height: 50px; object-fit: contain;">
        <?php else: ?>
            <h2><?php echo APP_NAME; ?></h2>
        <?php endif; ?>
    </div>
    <nav class="sidebar-nav">
        <div class="nav-item">
            <a href="dashboard.php" class="nav-link <?php echo $current_page == 'dashboard.php' ? 'active' : ''; ?>">
                <i>📊</i> Dashboard
            </a>
        </div>
        <?php if ($_SESSION['user_role'] == 'owner'): ?>
        <div class="nav-item">
            <a href="products.php" class="nav-link <?php echo $current_page == 'products.php' ? 'active' : ''; ?>">
                <i>☕</i> Products
            </a>
        </div>
        <div class="nav-item">
            <a href="categories.php" class="nav-link <?php echo $current_page == 'categories.php' ? 'active' : ''; ?>">
                <i>📁</i> Categories
            </a>
        </div>
        <?php endif; ?>
        <div class="nav-item">
            <a href="pos.php" class="nav-link <?php echo $current_page == 'pos.php' ? 'active' : ''; ?>">
                <i>💰</i> POS / Transactions
            </a>
        </div>
        <div class="nav-item">
            <a href="transactions.php" class="nav-link <?php echo $current_page == 'transactions.php' ? 'active' : ''; ?>">
                <i>📜</i> Transaction History
            </a>
        </div>
        <?php if ($_SESSION['user_role'] == 'owner'): ?>
        <div class="nav-item">
            <a href="cashiers.php" class="nav-link <?php echo $current_page == 'cashiers.php' ? 'active' : ''; ?>">
                <i>👥</i> Cashiers
            </a>
        </div>
        <div class="nav-item">
            <a href="theme_settings.php" class="nav-link <?php echo $current_page == 'theme_settings.php' ? 'active' : ''; ?>">
                <i>🎨</i> Theme Settings
            </a>
        </div>
        <?php endif; ?>
        <div class="nav-item">
            <a href="profile.php" class="nav-link <?php echo $current_page == 'profile.php' ? 'active' : ''; ?>">
                <i>👤</i> Profile
            </a>
        </div>
        <div class="nav-item">
            <a href="logout.php" class="nav-link">
                <i>🚪</i> Logout
            </a>
        </div>
    </nav>
</aside>

