# Quick Start Guide - BEANDESK POS System

## Installation Steps

### 1. Database Setup
1. Make sure XAMPP (or your web server) is running
2. Open your browser and navigate to:
   ```
   http://localhost/beandesk/install.php
   ```
3. The installer will:
   - Create the database `beandesk_pos`
   - Create all required tables
   - Set up the database structure

### 2. First Time Setup

#### Step 1: Register an Account
1. Go to `http://localhost/beandesk/register.php`
2. Fill in:
   - Full Name
   - Email
   - Username
   - Password (minimum 6 characters)
3. Click "Register"

#### Step 2: Set Up Your Café
1. After registration, you'll be redirected to the café setup page
2. Enter your café information:
   - Café Name (required)
   - Address
   - Description
   - Phone
3. Click "Complete Setup"

#### Step 3: Add Products
1. Go to "Products" in the sidebar
2. Click "+ Add Product"
3. Fill in product details:
   - Product Name
   - Category (default: General)
   - Price
   - Stock
   - Status (Available/Unavailable)
4. Click "Add Product"

#### Step 4: (Optional) Add Cashiers
1. Go to "Cashiers" in the sidebar (Owner only)
2. Click "+ Add Cashier"
3. Fill in cashier details:
   - Full Name
   - Email
   - Username
   - Password
4. Click "Add Cashier"

#### Step 5: Start Processing Transactions
1. Go to "POS / Transactions" in the sidebar
2. Click on products to add them to cart
3. Adjust quantities as needed
4. Enter discount and tax if applicable
5. Select order type and payment method
6. Click "Process Payment"
7. View and print the receipt

## Key Features

### Dashboard
- View café statistics
- See today's orders and revenue
- View product and cashier counts

### Product Management
- Add unlimited products
- Edit product details
- Delete products
- Track stock levels
- Set product availability

### POS System
- Quick product selection
- Real-time cart calculation
- Discount and tax support
- Multiple payment methods
- Receipt generation

### Cashier Management
- Add multiple cashier accounts
- Each cashier linked to your café
- Cashiers can process transactions
- Only owners can manage cashiers

## Important Notes

1. **One Café Per User**: Each registered user can only have one café
2. **Data Isolation**: All data is isolated per café - you'll only see your café's data
3. **Security**: All passwords are hashed and all queries use prepared statements
4. **Responsive Design**: Works on desktop and mobile devices

## Troubleshooting

### Database Connection Error
- Check if MySQL is running in XAMPP
- Verify database credentials in `config/database.php`
- Make sure database name is `beandesk_pos`

### Can't Access Pages
- Make sure you're logged in
- Check if café setup is completed
- Verify session is active

### Products Not Showing in POS
- Check product status (must be "Available")
- Verify stock levels
- Ensure products are linked to your café

## Support

For detailed documentation, see `README.md`

---

**Happy Selling! ☕**

