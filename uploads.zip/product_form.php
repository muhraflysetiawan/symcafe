<?php
require_once 'config/config.php';
requireLogin();
requireCafeSetup();
requireRole(['owner']);

$db = new Database();
$conn = $db->getConnection();
$cafe_id = getCafeId();

$error = '';
$success = '';
$product = null;
$is_edit = false;

// Get categories
$stmt = $conn->prepare("SELECT * FROM menu_categories WHERE cafe_id = ?");
$stmt->execute([$cafe_id]);
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

// If no categories, create default
if (empty($categories)) {
    $stmt = $conn->prepare("INSERT INTO menu_categories (cafe_id, category_name) VALUES (?, 'General')");
    $stmt->execute([$cafe_id]);
    $categories = [['category_id' => $conn->lastInsertId(), 'category_name' => 'General']];
}

// Handle edit - get product data
if (isset($_GET['id'])) {
    $item_id = (int)$_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM menu_items WHERE item_id = ? AND cafe_id = ?");
    $stmt->execute([$item_id, $cafe_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($product) {
        $is_edit = true;
    } else {
        header('Location: products.php');
        exit();
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $item_name = sanitizeInput($_POST['item_name'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0);
    $price = (float)($_POST['price'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $status = sanitizeInput($_POST['status'] ?? 'available');
    
    // Auto-update status based on stock
    if ($stock <= 0) {
        $status = 'unavailable';
    } elseif ($stock > 0 && $status == 'unavailable') {
        $status = 'available';
    }
    
    if (empty($item_name) || $price <= 0) {
        $error = 'Product name and price are required';
    } else {
        if ($is_edit && isset($_GET['id'])) {
            $item_id = (int)$_GET['id'];
            $stmt = $conn->prepare("UPDATE menu_items SET item_name = ?, category_id = ?, price = ?, stock = ?, status = ? WHERE item_id = ? AND cafe_id = ?");
            if ($stmt->execute([$item_name, $category_id, $price, $stock, $status, $item_id, $cafe_id])) {
                $success = 'Product updated successfully';
            } else {
                $error = 'Failed to update product';
            }
        } else {
            $stmt = $conn->prepare("INSERT INTO menu_items (cafe_id, category_id, item_name, price, stock, status) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$cafe_id, $category_id, $item_name, $price, $stock, $status])) {
                $success = 'Product added successfully';
                header('Location: products.php');
                exit();
            } else {
                $error = 'Failed to add product';
            }
        }
    }
}

$page_title = $is_edit ? 'Edit Product' : 'Add Product';
include 'includes/header.php';
?>

<h2 style="color: var(--primary-white); margin-bottom: 20px;"><?php echo $is_edit ? 'Edit Product' : 'Add New Product'; ?></h2>

<?php if ($error): ?>
    <div class="alert alert-error"><?php echo $error; ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="form-container">
    <form method="POST">
        <div class="form-row">
            <div class="form-group">
                <label for="item_name">Product Name *</label>
                <input type="text" id="item_name" name="item_name" required value="<?php echo htmlspecialchars($product['item_name'] ?? ''); ?>">
            </div>
            
            <div class="form-group">
                <label for="category_id">Category</label>
                <select id="category_id" name="category_id">
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo $cat['category_id']; ?>" <?php echo (isset($product['category_id']) && $product['category_id'] == $cat['category_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($cat['category_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        
        <div class="form-row">
            <div class="form-group">
                <label for="price">Price *</label>
                <input type="number" id="price" name="price" step="0.01" min="0" required value="<?php echo $product['price'] ?? ''; ?>">
            </div>
            
            <div class="form-group">
                <label for="stock">Stock</label>
                <input type="number" id="stock" name="stock" min="0" value="<?php echo $product['stock'] ?? 0; ?>">
            </div>
        </div>
        
        <div class="form-group">
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="available" <?php echo (isset($product['status']) && $product['status'] == 'available') ? 'selected' : ''; ?>>Available</option>
                <option value="unavailable" <?php echo (isset($product['status']) && $product['status'] == 'unavailable') ? 'selected' : ''; ?>>Unavailable</option>
            </select>
        </div>
        
        <div style="display: flex; gap: 10px; margin-top: 20px;">
            <button type="submit" class="btn btn-primary"><?php echo $is_edit ? 'Update Product' : 'Add Product'; ?></button>
            <a href="products.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>

