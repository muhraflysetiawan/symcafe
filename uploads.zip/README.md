# BEANDESK - POS System for Cafés

A modern Point of Sale (POS) system designed specifically for cafés, featuring a sleek black and white theme and complete data isolation per café.

## Features

### User Management
- User registration with email, username, and password
- Secure password hashing
- Role-based access control (Owner, Cashier)
- User profile management

### Café Management
- One café per user account
- Café profile setup (name, address, description, phone)
- Automatic café detection and data isolation

### Product Management
- Add, edit, and delete products
- Product categories
- Stock management
- Product status (available/unavailable)
- Price management

### Cashier Management
- Add cashier accounts (Owner only)
- Edit and delete cashiers
- Cashiers are linked to the owner's café

### Transaction System (POS)
- Modern POS interface
- Add products to cart
- Quantity management
- Automatic total calculation
- Discount support
- Tax calculation
- Multiple payment methods (Cash, QRIS, Debit, Credit)
- Order types (Dine-in, Take-away, Online)
- Receipt generation and printing

### Dashboard
- Café statistics
- Today's orders count
- Today's revenue
- Product count
- Cashier count

### Security Features
- Password hashing (bcrypt)
- Prepared statements (SQL injection prevention)
- Input sanitization
- Session management
- Data isolation per café
- Role-based access control

## Installation

1. **Database Setup**
   - Ensure MySQL/MariaDB is running
   - Open `install.php` in your browser
   - The script will create the database and all required tables

2. **Configuration**
   - Update `config/database.php` with your database credentials if needed
   - Update `config/config.php` with your base URL if different from `http://localhost/beandesk/`

3. **Access the System**
   - Navigate to `login.php` or `register.php`
   - Create a new account
   - Complete café setup
   - Start using the system!

## System Flow

1. **Registration**: User creates an account
2. **Café Setup**: User must set up their café profile immediately after registration
3. **Product Management**: Add products to the menu
4. **Cashier Management**: (Owner only) Add cashier accounts
5. **POS Transactions**: Process orders and payments
6. **Receipt Printing**: Generate and print receipts

## Data Isolation

Each café's data is completely isolated:
- Products are linked to café ID
- Orders are linked to café ID
- Cashiers belong to specific cafés
- All queries filter by café ID automatically

## File Structure

```
beandesk/
├── assets/
│   └── css/
│       └── style.css          # Main stylesheet (black/white theme)
├── config/
│   ├── config.php              # Application configuration
│   └── database.php            # Database connection
├── database/
│   ├── schema.sql              # Database schema
│   └── pos_minimart.sql        # (Empty - can be removed)
├── includes/
│   ├── header.php              # Page header
│   ├── footer.php              # Page footer
│   ├── sidebar.php             # Navigation sidebar
│   └── topnav.php              # Top navigation
├── dashboard.php               # Main dashboard
├── login.php                   # Login page
├── register.php                # Registration page
├── cafe_setup.php             # Café setup page
├── products.php                # Product list
├── product_form.php           # Add/Edit product
├── cashiers.php               # Cashier management
├── cashier_form.php           # Add/Edit cashier
├── pos.php                     # POS interface
├── process_transaction.php    # Process payment
├── receipt.php                 # Receipt page
├── profile.php                 # User profile
├── logout.php                  # Logout handler
├── index.php                   # Redirect handler
└── install.php                 # Database installer
```

## Database Schema

- **users**: User accounts (owners and cashiers)
- **cafes**: Café information
- **menu_categories**: Product categories
- **menu_items**: Products/menu items
- **orders**: Transaction orders
- **order_items**: Order line items
- **payments**: Payment records
- **customers**: Customer information (optional)
- **inventory_logs**: Stock change logs
- **activity_logs**: User activity logs

## Requirements

- PHP 7.4 or higher
- MySQL 5.7 or higher / MariaDB 10.2 or higher
- Web server (Apache/Nginx)
- Modern web browser

## Theme

The system uses a modern black (#252525) and white (#FFFFFF) color scheme with:
- Clean, minimal design
- Responsive layout (mobile and desktop)
- Modern UI components
- Print-friendly receipt design

## Security Notes

- All passwords are hashed using PHP's `password_hash()` function
- All database queries use prepared statements
- Input is sanitized before processing
- Session-based authentication
- Data isolation ensures users only see their café's data

## Support

For issues or questions, please check the code comments or database schema for implementation details.

---

**Version**: 1.0  
**License**: Proprietary
