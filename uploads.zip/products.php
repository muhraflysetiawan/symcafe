<?php
require_once 'config/config.php';
requireLogin();
requireCafeSetup();
requireRole(['owner']);

$db = new Database();
$conn = $db->getConnection();
$cafe_id = getCafeId();

$message = '';
$message_type = '';

// Handle delete
if (isset($_GET['delete']) && $_GET['delete']) {
    $item_id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM menu_items WHERE item_id = ? AND cafe_id = ?");
    if ($stmt->execute([$item_id, $cafe_id])) {
        $message = 'Product deleted successfully';
        $message_type = 'success';
    } else {
        $message = 'Failed to delete product';
        $message_type = 'error';
    }
}

// Auto-update product status based on stock
$stmt = $conn->prepare("UPDATE menu_items SET status = 'unavailable' WHERE cafe_id = ? AND stock <= 0 AND status = 'available'");
$stmt->execute([$cafe_id]);

$stmt = $conn->prepare("UPDATE menu_items SET status = 'available' WHERE cafe_id = ? AND stock > 0 AND status = 'unavailable'");
$stmt->execute([$cafe_id]);

// Get all products with categories
$stmt = $conn->prepare("
    SELECT mi.*, mc.category_name 
    FROM menu_items mi 
    LEFT JOIN menu_categories mc ON mi.category_id = mc.category_id 
    WHERE mi.cafe_id = ? 
    ORDER BY mi.created_at DESC
");
$stmt->execute([$cafe_id]);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = 'Products';
include 'includes/header.php';
?>

<h2 style="color: var(--primary-white); margin-bottom: 20px;">Products</h2>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $message_type; ?>"><?php echo $message; ?></div>
<?php endif; ?>

<div class="table-container">
    <div class="table-header">
        <div class="table-title">Product List</div>
        <a href="product_form.php" class="btn btn-primary btn-sm">+ Add Product</a>
    </div>
    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($products)): ?>
                <tr>
                    <td colspan="6" style="text-align: center; color: var(--text-gray);">No products found. <a href="product_form.php" style="color: var(--primary-white);">Add your first product</a></td>
                </tr>
            <?php else: ?>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td style="color: var(--primary-white); font-weight: 500;"><?php echo htmlspecialchars($product['item_name']); ?></td>
                        <td><?php echo htmlspecialchars($product['category_name'] ?? 'General'); ?></td>
                        <td><?php echo formatCurrency($product['price']); ?></td>
                        <td><?php echo $product['stock']; ?></td>
                        <td>
                            <span class="badge badge-<?php echo $product['status'] == 'available' ? 'success' : 'danger'; ?>">
                                <?php echo ucfirst($product['status']); ?>
                            </span>
                        </td>
                        <td>
                            <a href="product_form.php?id=<?php echo $product['item_id']; ?>" class="btn btn-secondary btn-sm">Edit</a>
                            <a href="?delete=<?php echo $product['item_id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this product?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php include 'includes/footer.php'; ?>

