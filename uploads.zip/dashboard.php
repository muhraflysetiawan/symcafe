<?php
require_once 'config/config.php';
requireLogin();
requireCafeSetup();

$db = new Database();
$conn = $db->getConnection();
$cafe_id = getCafeId();

// Get café info
$stmt = $conn->prepare("SELECT * FROM cafes WHERE cafe_id = ?");
$stmt->execute([$cafe_id]);
$cafe = $stmt->fetch(PDO::FETCH_ASSOC);

// Get statistics
$stmt = $conn->prepare("SELECT COUNT(*) as total FROM menu_items WHERE cafe_id = ?");
$stmt->execute([$cafe_id]);
$total_products = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM orders WHERE cafe_id = ? AND DATE(created_at) = CURDATE()");
$stmt->execute([$cafe_id]);
$today_orders = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$stmt = $conn->prepare("SELECT SUM(total_amount) as total FROM orders WHERE cafe_id = ? AND DATE(created_at) = CURDATE() AND payment_status = 'paid'");
$stmt->execute([$cafe_id]);
$today_revenue = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

$stmt = $conn->prepare("SELECT COUNT(*) as total FROM users WHERE cafe_id = ? AND role = 'cashier'");
$stmt->execute([$cafe_id]);
$total_cashiers = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

$page_title = 'Dashboard';
include 'includes/header.php';
?>

<h2 style="color: var(--primary-white); margin-bottom: 20px;">Dashboard</h2>

<div class="dashboard-grid">
    <div class="dashboard-card">
        <div class="card-header">
            <div class="card-icon primary">☕</div>
            <div class="card-title">Total Products</div>
        </div>
        <div class="card-value"><?php echo $total_products; ?></div>
        <div class="card-subtitle">Menu items in your café</div>
    </div>
    
    <div class="dashboard-card">
        <div class="card-header">
            <div class="card-icon success">📋</div>
            <div class="card-title">Today's Orders</div>
        </div>
        <div class="card-value"><?php echo $today_orders; ?></div>
        <div class="card-subtitle">Orders processed today</div>
    </div>
    
    <div class="dashboard-card">
        <div class="card-header">
            <div class="card-icon warning">💰</div>
            <div class="card-title">Today's Revenue</div>
        </div>
        <div class="card-value"><?php echo formatCurrency($today_revenue); ?></div>
        <div class="card-subtitle">Total sales today</div>
    </div>
    
    <?php if ($_SESSION['user_role'] == 'owner'): ?>
    <div class="dashboard-card">
        <div class="card-header">
            <div class="card-icon danger">👥</div>
            <div class="card-title">Cashiers</div>
        </div>
        <div class="card-value"><?php echo $total_cashiers; ?></div>
        <div class="card-subtitle">Active cashier accounts</div>
    </div>
    <?php endif; ?>
</div>

<div class="table-container" style="margin-top: 30px;">
    <div class="table-header">
        <div class="table-title">Café Information</div>
        <?php if ($_SESSION['user_role'] == 'owner'): ?>
            <a href="cafe_edit.php" class="btn btn-primary btn-sm">Edit Information</a>
        <?php endif; ?>
    </div>
    <table class="table">
        <tbody>
            <tr>
                <td style="font-weight: 600; color: var(--primary-white);">Café Name</td>
                <td><?php echo htmlspecialchars($cafe['cafe_name']); ?></td>
            </tr>
            <tr>
                <td style="font-weight: 600; color: var(--primary-white);">Address</td>
                <td><?php echo !empty($cafe['address']) ? htmlspecialchars($cafe['address']) : 'Not set'; ?></td>
            </tr>
            <tr>
                <td style="font-weight: 600; color: var(--primary-white);">Description</td>
                <td><?php echo !empty($cafe['description']) ? htmlspecialchars($cafe['description']) : 'Not set'; ?></td>
            </tr>
            <tr>
                <td style="font-weight: 600; color: var(--primary-white);">Phone</td>
                <td><?php echo !empty($cafe['phone']) ? htmlspecialchars($cafe['phone']) : 'Not set'; ?></td>
            </tr>
        </tbody>
    </table>
</div>

<?php include 'includes/footer.php'; ?>
