<?php
require_once 'config/config.php';
requireLogin();
requireCafeSetup();

$db = new Database();
$conn = $db->getConnection();
$cafe_id = getCafeId();

// Get all available products
$stmt = $conn->prepare("SELECT * FROM menu_items WHERE cafe_id = ? AND status = 'available' ORDER BY item_name");
$stmt->execute([$cafe_id]);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = 'POS / Transactions';
include 'includes/header.php';

// Display error message if any
$error = '';
if (isset($_SESSION['error'])) {
    $error = $_SESSION['error'];
    unset($_SESSION['error']);
}
?>

<h2 style="color: var(--primary-white); margin-bottom: 20px;">Point of Sale</h2>

<?php if ($error): ?>
    <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="pos-container">
    <div class="pos-products">
        <h3 style="color: var(--primary-white); margin-bottom: 15px;">Products</h3>
        <div class="product-grid" id="productGrid">
            <?php foreach ($products as $product): ?>
                <div class="product-card <?php echo $product['stock'] <= 0 ? 'unavailable' : ''; ?>" 
                     data-id="<?php echo $product['item_id']; ?>"
                     data-name="<?php echo htmlspecialchars($product['item_name']); ?>"
                     data-price="<?php echo $product['price']; ?>"
                     data-stock="<?php echo $product['stock']; ?>">
                    <div class="product-name"><?php echo htmlspecialchars($product['item_name']); ?></div>
                    <div class="product-price"><?php echo formatCurrency($product['price']); ?></div>
                    <div class="product-stock">Stock: <?php echo $product['stock']; ?></div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <div class="pos-cart">
        <h3 style="color: var(--primary-white); margin-bottom: 15px;">Cart</h3>
        <form id="posForm" method="POST" action="process_transaction.php">
            <div id="cartItems"></div>
            
            <div class="cart-summary">
                <div class="summary-row">
                    <span>Subtotal:</span>
                    <span id="subtotal">Rp 0</span>
                </div>
                <div class="form-group" style="margin-top: 15px;">
                    <label for="discount">Discount (Rp)</label>
                    <input type="number" id="discount" name="discount" step="0.01" min="0" value="0" onchange="calculateTotal()">
                </div>
                <div class="form-group">
                    <label for="tax">Tax (%)</label>
                    <input type="number" id="tax" name="tax" step="0.01" min="0" value="0" onchange="calculateTotal()">
                </div>
                <div class="summary-row total">
                    <span>Total:</span>
                    <span id="total">Rp 0</span>
                </div>
                
                <div class="form-group" style="margin-top: 15px;">
                    <label for="customer_name">Customer Name (Optional)</label>
                    <input type="text" id="customer_name" name="customer_name" placeholder="Enter customer name">
                </div>
                
                <div class="form-group" style="margin-top: 15px;">
                    <label for="order_type">Order Type</label>
                    <select id="order_type" name="order_type" required>
                        <option value="dine-in">Dine In</option>
                        <option value="take-away">Take Away</option>
                        <option value="online">Online</option>
                    </select>
                </div>
                
                <div class="form-group" style="margin-top: 15px;">
                    <label for="payment_method">Payment Method</label>
                    <select id="payment_method" name="payment_method" required>
                        <option value="cash">Cash</option>
                        <option value="qris">QRIS</option>
                        <option value="debit">Debit Card</option>
                        <option value="credit">Credit Card</option>
                    </select>
                </div>
                
                <input type="hidden" id="cartData" name="cart_data">
                <input type="hidden" id="subtotalValue" name="subtotal_value">
                <input type="hidden" id="discountValue" name="discount_value">
                <input type="hidden" id="taxValue" name="tax_value">
                <input type="hidden" id="totalValue" name="total_value">
                
                <button type="submit" class="btn btn-primary btn-full" style="margin-top: 20px;" id="checkoutBtn" disabled>Process Payment</button>
                <button type="button" class="btn btn-secondary btn-full" style="margin-top: 10px;" onclick="clearCart()">Clear Cart</button>
            </div>
        </form>
    </div>
</div>

<script>
let cart = [];

document.querySelectorAll('.product-card').forEach(card => {
    if (!card.classList.contains('unavailable')) {
        card.addEventListener('click', function() {
            const id = parseInt(this.dataset.id);
            const name = this.dataset.name;
            const price = parseFloat(this.dataset.price);
            const stock = parseInt(this.dataset.stock);
            
            addToCart(id, name, price, stock);
        });
    }
});

function addToCart(id, name, price, stock) {
    const existingItem = cart.find(item => item.id === id);
    
    if (existingItem) {
        if (existingItem.quantity < stock) {
            existingItem.quantity++;
        } else {
            alert('Stock limit reached');
            return;
        }
    } else {
        cart.push({ id, name, price, stock, quantity: 1 });
    }
    
    updateCart();
}

function removeFromCart(id) {
    cart = cart.filter(item => item.id !== id);
    updateCart();
}

function updateQuantity(id, change) {
    const item = cart.find(item => item.id === id);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            removeFromCart(id);
            return;
        }
        if (item.quantity > item.stock) {
            item.quantity = item.stock;
            alert('Stock limit reached');
        }
    }
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById('cartItems');
    cartItems.innerHTML = '';
    
    if (cart.length === 0) {
        cartItems.innerHTML = '<p style="color: var(--text-gray); text-align: center;">Cart is empty</p>';
        document.getElementById('checkoutBtn').disabled = true;
        calculateTotal();
        return;
    }
    
    document.getElementById('checkoutBtn').disabled = false;
    
    cart.forEach(item => {
        const cartItem = document.createElement('div');
        cartItem.className = 'cart-item';
        cartItem.innerHTML = `
            <div class="cart-item-info">
                <div class="cart-item-name">${item.name}</div>
                <div class="cart-item-price">${formatCurrency(item.price)} x ${item.quantity}</div>
            </div>
            <div class="cart-item-controls">
                <div class="quantity-control">
                    <button type="button" class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                    <input type="number" class="quantity-input" value="${item.quantity}" min="1" max="${item.stock}" onchange="setQuantity(${item.id}, this.value)">
                    <button type="button" class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
                </div>
                <button type="button" class="btn btn-danger btn-sm" onclick="removeFromCart(${item.id})">Remove</button>
            </div>
        `;
        cartItems.appendChild(cartItem);
    });
    
    calculateTotal();
}

function setQuantity(id, quantity) {
    const item = cart.find(item => item.id === id);
    if (item) {
        quantity = parseInt(quantity);
        if (quantity < 1) quantity = 1;
        if (quantity > item.stock) quantity = item.stock;
        item.quantity = quantity;
        updateCart();
    }
}

function calculateTotal() {
    let subtotal = 0;
    cart.forEach(item => {
        subtotal += item.price * item.quantity;
    });
    
    const discount = parseFloat(document.getElementById('discount').value) || 0;
    const taxPercent = parseFloat(document.getElementById('tax').value) || 0;
    
    const afterDiscount = subtotal - discount;
    const tax = (afterDiscount * taxPercent) / 100;
    const total = afterDiscount + tax;
    
    document.getElementById('subtotal').textContent = formatCurrency(subtotal);
    document.getElementById('total').textContent = formatCurrency(total);
    
    document.getElementById('cartData').value = JSON.stringify(cart);
    document.getElementById('subtotalValue').value = subtotal;
    document.getElementById('discountValue').value = discount;
    document.getElementById('taxValue').value = tax;
    document.getElementById('totalValue').value = total;
}

function clearCart() {
    if (confirm('Are you sure you want to clear the cart?')) {
        cart = [];
        updateCart();
        document.getElementById('discount').value = 0;
        document.getElementById('tax').value = 0;
    }
}

function formatCurrency(amount) {
    return 'Rp ' + amount.toLocaleString('id-ID');
}

// Initialize
updateCart();
</script>

<?php include 'includes/footer.php'; ?>

