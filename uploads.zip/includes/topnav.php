<?php
$db = new Database();
$conn = $db->getConnection();
$cafe_id = getCafeId();

$cafe_name = 'My Café';
if ($cafe_id) {
    $stmt = $conn->prepare("SELECT cafe_name FROM cafes WHERE cafe_id = ?");
    $stmt->execute([$cafe_id]);
    $cafe = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($cafe) {
        $cafe_name = $cafe['cafe_name'];
    }
}
?>
<nav class="top-nav">
    <div style="display: flex; align-items: center; gap: 15px;">
        <button class="mobile-menu-btn">☰</button>
        <h1><?php echo $cafe_name; ?></h1>
    </div>
    <div class="user-info">
        <div class="user-details">
            <div class="user-name"><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?></div>
            <div class="user-role"><?php echo htmlspecialchars($_SESSION['user_role'] ?? 'user'); ?></div>
        </div>
        <div class="user-avatar">
            <?php echo strtoupper(substr($_SESSION['user_name'] ?? 'U', 0, 1)); ?>
        </div>
    </div>
</nav>

